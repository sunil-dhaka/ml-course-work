#!/bin/bash
jupyter nbconvert --to notebook --execute anomaly.ipynb