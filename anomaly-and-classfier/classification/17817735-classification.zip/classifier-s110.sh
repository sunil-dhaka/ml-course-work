#!/bin/bash

echo "Test File is: $1"
# read x
# echo $x
python classifier-s110.py "$1"