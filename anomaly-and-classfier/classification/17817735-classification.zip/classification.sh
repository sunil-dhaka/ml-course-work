#!/bin/bash
jupyter nbconvert --to notebook --execute classification.ipynb